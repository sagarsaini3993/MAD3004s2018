//
//  Employee.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Employee {
    var employeeID: Int?
    var employeeName : String?
    var employeeEmail: String?
    var employeeMobile: Int?
    var employeeAddress: String?
    var employeeDesignation: String?
    var employeeSinNumber: String?
    
    var EmployeeID : Int?
    {
        get
        {
            return self.EmployeeID
        }
        set
        {
            self.EmployeeID = newValue
        }
    }
    var EmployeeName : String?
    {
        get
        {
            return self.employeeName
        }
        set
        {
            self.employeeName = newValue
        }
    }
    var EmployeeEmail : String?
    {
        get
        {
            return self.employeeEmail
        }
        set
        {
            self.employeeEmail = newValue
        }
    }
    var EmployeeMobile : Int?
    {
        get
        {
            return self.employeeMobile
        }
        set
        {
            self.employeeMobile = newValue
        }
    }
    var EmployeeAdress : String?
    {
        get
        {
            return self.employeeAddress
        }
        set
        {
            self.employeeAddress = newValue
        }
    }
    var EmployeeDesignation : String?
    {
        get
        {
            return self.employeeDesignation
        }
        set
        {
            self.employeeDesignation = newValue
        }
    }
    var EmployeeSinNumber : String?
    {
        get
        {
            return self.employeeSinNumber
        }
        set
        {
            self.employeeSinNumber = newValue
        }
    }
    
   
    init() {
        self.employeeID = 0
        self.employeeName = ""
        self.employeeEmail = ""
     
        self.employeeMobile = 0
        self.EmployeeAdress = ""
        self.employeeDesignation = ""
    }
    
    init(employeeID : Int, employeeName : String, employeeEmail : String, employeeMobile : Int, employeeAdress : String, employeeDesignation : String, employeeSinNumber: String) {
        
        self.EmployeeID = employeeID
        self.EmployeeName = employeeName
        self.EmployeeEmail = employeeEmail
        self.EmployeeMobile = employeeMobile
        self.EmployeeAdress = employeeAdress
        self.EmployeeDesignation = employeeDesignation
        self.EmployeeSinNumber = employeeSinNumber
        
    }
    
    func displayData() -> String {
        
        var returnData = ""
        
        if self.EmployeeID != nil {
            returnData += "\n EmployeeID : " + String(self.EmployeeID!)
        }
        if self.EmployeeName != nil {
            returnData += "\n EmployeeName : " + self.EmployeeName!
        }
        if self.EmployeeEmail != nil {
            returnData += "\n EmployeeEmail : " + self.EmployeeEmail!
        }
        //        if self.flightScheduleDate != nil {
        //            returnData += "\n Flight schedule : " + String(self.flightScheduleDate!)
        //        }
        if self.EmployeeMobile != nil {
            returnData += "\n EmployeeMobile: " + String(self.EmployeeMobile!)
        }
        if self.EmployeeAdress != nil {
            returnData += "\n EmployeeAdress: " + self.EmployeeAdress!
        }
        if self.EmployeeDesignation != nil {
            returnData += "\n EmployeeDesignation : " + self.EmployeeDesignation!
        }
        
        return returnData
        
    }
    
    
}
