//
//  PlaneType.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class PlaneType{
    var type : PlaneType?
    func newProduct() {
        
        print("please choose category")
        for type in PlaneType.allCases
        {
            print("enter \(type.rawValue) for \(type)")
        }
        let choice = (Int) (readLine()!) ?? 5
        self.type = PlaneType(rawValue: choice)
        
    }
}
