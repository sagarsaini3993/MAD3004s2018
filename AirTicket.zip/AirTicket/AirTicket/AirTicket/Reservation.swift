//
//  Reservation.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Reservation : PassengerInfo {
    var passengerId: Int
    
    var passengerPassportNumber: String
    
    var passengerName: String
    
    var passengerMobile: Int
    
    var passengerEmail: String
    
    var passengerAddress: String
    
    
    
    
    var resID : Int?
    var resDesc : String?
   
    var resFlightId : Int?
   // var resDate : Date?
    var resSeatNumber : String?
    var resStatus : String?
    var resMealType : String?
    
    var ResID : Int?
    {
        get
        {
            return self.resID
        }
        set
        {
            self.resID = newValue
        }
    }
    var ResDesc : String?
    {
        get
        {
            return self.resDesc
        }
        set
        {
            self.resDesc = newValue
        }
    }
    var PassengerId : Int?
    {
        get
        {
            return self.passengerId
        }
        set
        {
            self.passengerId = newValue as! Int
        }
    }
    var ResFlightId : Int?
    {
        get
        {
            return self.resFlightId
        }
        set
        {
            self.resFlightId = newValue
        }
    }
//    var ResDate : Date?
//    {
//        get
//        {
//            return self.resDate
//        }
//        set
//        {
//            self.resDate = newValue
//        }
//    }
    var ResSeatNumber : String?
    {
        get
        {
            return self.resSeatNumber
        }
        set
        {
            self.resSeatNumber = newValue
        }
    }
    var ResStatus : String?
    {
        get
        {
            return self.resStatus
        }
        set
        {
            self.resStatus = newValue
        }
    }
    var ResMealType : String?
    {
        get
        {
            return self.resMealType
        }
        set
        {
            self.resMealType = newValue
        }
    }
    
    
//    init() {
//        self.resID = 0
//        self.resDesc = ""
//        self.passengerId = 0
//        self.resFlightId = 0
//       // self.resDate = 00/00/0000
//        self.resSeatNumber = ""
//        self.resStatus = ""
//        self.resMealType = ""
//    }
    
    init(passengerId : Int, passengerPassportNumber: String, passengerName: String, passengerMobile: Int,  passengerEmail: String, passengerAddress: String, resDesc : String, resFlightId : Int, resSeatNumber : String, resStatus: String, resMealType: String) {
        self.passengerId = passengerId
        self.passengerPassportNumber = passengerPassportNumber
        self.passengerName = passengerName
        self.passengerMobile = passengerMobile
        self.passengerEmail = passengerEmail
        self.passengerAddress = passengerAddress
        self.resID = resID
        self.resDesc = resDesc
        self.resFlightId = resFlightId
        self.resSeatNumber = resSeatNumber
        self.resStatus = resStatus
        self.resMealType = resMealType
        
    }
    
    func displayData() -> String {
        
        var returnData = ""
        
        if self.ResID != nil {
            returnData += "\n resID : " + String(self.resID!)
        }
        if self.ResDesc != nil {
            returnData += "\n resDesc : " + self.resDesc!
        }
        if self.PassengerId != nil {
            returnData += "\n resPassengerId : " + String(self.passengerId)
        }
        //        if self.flightScheduleDate != nil {
        //            returnData += "\n Flight schedule : " + String(self.flightScheduleDate!)
        //        }
        if self.ResFlightId != nil {
            returnData += "\n EmployeeMobile: " + String(self.resFlightId!)
        }
        if self.ResSeatNumber != nil {
            returnData += "\n resSeatNumber: " + String(self.resSeatNumber!)
        }
        if self.ResMealType != nil {
            returnData += "\n resMealType : " + self.resMealType!
        }
        
        return returnData
        
    }
    
    
}
