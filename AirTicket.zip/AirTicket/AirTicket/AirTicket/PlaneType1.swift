//
//  PlaneType1.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class PlaneType : IDisplay{
    
    var ptype : PlaneType?
    var Ptype : PlaneType
    {
        get
        {
            return self.ptype!
        }set
        {
            self.ptype = newValue
        }
    }
    
    func newType() {
        
        print("please choose type")
        for type in PlaneType.allCases
        {
            print("enter \(type.rawValue) for \(type)")
        }
        let choice = (Int) (readLine()!) ?? 5
        self.ptype = PlaneType(rawValue: choice)
        
    }
    
    init()
    {
        
        self.ptype = PlaneType.None
    }
    
    init(ptype: PlaneType)
    {
        
        self.ptype = ptype
    }
    
    func displayData() -> String{
        var returnData = ""
        
        returnData += "\n Type : \(self.ptype ?? PlaneType.None)"
        return returnData
    }
    
    
}
