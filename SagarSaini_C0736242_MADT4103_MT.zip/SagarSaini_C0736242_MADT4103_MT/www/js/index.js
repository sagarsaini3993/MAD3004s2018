
document.getElementById("findMyRide").addEventListener("click",book);
function book(){

  var from = document.getElementById("from").value;
  var to = document.getElementById("to").value;


if (from == "275 Yorkland Blvd" && to == "CN Tower") {
  var from = document.getElementById("from").value;
  var to = document.getElementById("to").value;

  document.getElementById("fromm").innerHTML = from;
  document.getElementById("too").innerHTML = to;

  document.getElementById("bookFee").innerHTML = "$2.50";
  document.getElementById("distanceCharge").innerHTML = 0.81*22.9;
  document.getElementById("serviceFee").innerHTML = "$1.75";




  var ride = document.getElementsByName('ride');

  for (var i = 0, length = ride.length; i < length; i++)
  {
   if (ride[i].checked)
   {

  if(ride[i].value="pool")
  {
      console.log("pool");
  }
  else
  {
      console.log("direct");
  }

    break;
   }
  }
  console.log("from:"+from);
  console.log("To:"+to);

  document.getElementById("fromNext").innerHTML = from;
  document.getElementById("toNext").innerHTML = to;


  var total=(2.50)+(0)+(1.75);
  document.getElementById("total").innerHTML = "$"+total;
}


if (from == "Fairview Mall" && to == "Tim Hortons") {
  var from = document.getElementById("from").value;
  var to = document.getElementById("to").value;

  document.getElementById("fromm").innerHTML = from;
  document.getElementById("too").innerHTML = to;

  document.getElementById("bookFee").innerHTML = "$2.50";
  document.getElementById("distanceCharge").innerHTML = 0.81*1.2;
  document.getElementById("serviceFee").innerHTML = "$1.75";




  var ride = document.getElementsByName('ride');

  for (var i = 0, length = ride.length; i < length; i++)
  {
   if (ride[i].checked)
   {

  if(ride[i].value="pool")
  {
      console.log("pool");
  }
  else
  {
      console.log("direct");
  }

    break;
   }
  }
  console.log("from:"+from);
  console.log("To:"+to);

  document.getElementById("fromNext").innerHTML = from;
  document.getElementById("toNext").innerHTML = to;


  var total=(2.50)+(0)+(1.75);
  document.getElementById("total").innerHTML = "$"+total;
}


else {
  alert("Invalid locations");
}



}
