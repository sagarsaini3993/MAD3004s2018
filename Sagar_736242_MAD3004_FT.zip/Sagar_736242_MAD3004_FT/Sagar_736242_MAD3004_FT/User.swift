//
//  User.swift
//  Sagar_736242_MAD3004_FT
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class User : IDisplay{
    
    
 var userID: String
    var name : String
   var address : String
     var contactNo : String
   var password : String
    
    var UserID : String?{
        get{ return self.userID }
        set{ self.userID = newValue as! String }
    }
    
    var Name : String?{
        get{ return self.name }
        set{ self.name = newValue as! String }
    }
    
    var Address : String?{
        get { return self.address}
        set {self.address = newValue as! String}
    }
    var ContactNo : String?{
        get { return self.contactNo}
        set {self.contactNo = newValue as! String}
    }
    var Password : String?{
        get { return self.password}
        set {self.password = newValue as! String}
    }
    
    
    init(){
        self.userID = ""
        self.name = ""
        self.address = ""
        self.contactNo = ""
        self.password = ""
    }
    
    init(userID: String, name: String, address: String, contactNo: String, password: String){
        self.userID = userID
        self.name = name
        self.address = address
        self.contactNo = contactNo
        self.password = password
    }
    
    func display() -> String {
        var returnData = ""
        returnData += "\t \(self.userID ?? "") ------ \(self.name ?? "") ------ \(self.address ?? "") ------ \(self.contactNo ?? "") ------ \(self.password ?? "")"
        return returnData
    }
}
