//
//  Author.swift
//  Sagar_736242_MAD3004_FT
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Author : IDisplay{
    
    var authorID: String
    var name : String
    var country : String
    
    init(){
        self.authorID = ""
        self.name = ""
        self.country = ""
    }
    
    init(authorID: String, name: String, country: String){
        self.authorID = authorID
        self.name = name
        self.country = country
    }
    
     func display() -> String {
        var returnData = ""
        returnData += "\t \(self.authorID ?? "") ------ \(self.name ?? "") ------ \(self.country ?? "")"
        return returnData
    }
    
}

