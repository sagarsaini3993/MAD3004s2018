//
//  DataHelper.swift
//  Sagar_736242_MAD3004_FT
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper {
    var BookList = [Int : Book]()
    var UserList = [String : User]()
    
    init() {
        self.loadBooksData()
        self.loadUserData()
    }
    
    func loadBooksData() {
        
        BookList = [:]
        
        do {
            let book1 = try Book(bookID: "11", title: "QWERTY", category: BookCategory.Drama, refundablePrice: 1.3, authorID: "A11", name: "A.Paul", country: "Canada")
            BookList[Int(book1.BookID!)!] = book1
            
            let book2 = try Book(bookID: "21", title: "ASD", category: BookCategory.Fiction, refundablePrice: 3.1, authorID: "C13", name: "Tom", country: "USA")
            BookList[Int(book2.BookID!)!] = book2
            
            let book3 = try Book(bookID: "31", title: "ZXC", category: BookCategory.Biography, refundablePrice: 0.5, authorID: "N16", name: "Elly", country: "France")
            BookList[Int(book3.BookID!)!] = book3
            
            let book4 = try Book(bookID: "41", title: "PO", category: BookCategory.Romance, refundablePrice: 0.6, authorID: "R18", name: "Cruze", country: "UK")
            BookList[Int(book4.BookID!)!] = book4
            
            let book5 = try Book(bookID: "51", title: "YU", category: BookCategory.Thriller, refundablePrice: 3.2, authorID: "P71", name: "Patrick", country: "Russia")
            
            
        } catch {
            print("Error")
        }
    }
    
    func loadUserData() {
        
    }
    
    func displayBooks() {
        print("Books Details")
        Util.drawLine()
        print("\t ID----\t\t Title\t\t\t\t----Category\t\t----Refundable Price\t\t----Author")
        for (_, value) in self.BookList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.BookID!) ------ \(value.Title!) ------ \(value.Category!) ------ \(value.RefundablePrice!) ------ \(value.name)")
        }
        Util.drawLine()
    }
    
    func searchBook(bookID : Int) -> Book?{
        if BookList[bookID] != nil{
            return BookList[bookID]! as Book
        }
        else{
            print("Sorry..The book number you have entered is not available")
            return nil
        }
    }
    
    func loadUsersData(){
        BookList = [:]
        
        let Raman = User(userID: "11", name: "raman", address: "brampton", contactNo: "123654", password: "12345678")
        UserList[Raman.UserID!] = Raman
        
        let Sagar = User(userID: "13", name: "sagar", address: "Toronto", contactNo: "789654", password: "87654321")
        UserList[Sagar.UserID!] = Sagar
    }
}
