//
//  BookIssue.swift
//  Sagar_736242_MAD3004_FT
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

typealias bookIssue = (bookId: Int, book: Book)

class BookIssue : User {
    
    
    private var issueID : Int
    private var userInfo : User
    private var issueDate : Date
    private var booksIssued : [Book]
    private var issueAmount : Double
    private var booksOrdered : [bookIssue]
    private var dataHelper = DataHelper()

    
    var IssueID : Int? {
        get { return self.issueID }
        set{ self.issueID = newValue as! Int}
    }
    var UserInfo : User? {
        get { return self.userInfo }
        set{ self.userInfo = newValue as! User}
    }
    var IssueDate : Date?{
        get { return self.issueDate }
        set{ self.issueDate = newValue as! Date}
    }
    var BooksIssued : [Book]?{
        get { return self.booksIssued }
        set{ self.booksIssued = newValue as! [Book]}
    }
    var IssueAmount : Double?{
        get { return self.issueAmount }
        set{ self.issueAmount = newValue as! Double}
    }
    
    var orderAmount: Double?{
        get{
            var amount = 0.0
            if !self.booksOrdered.isEmpty{
                for (_, book) in self.booksOrdered {
                    amount += book.RefundablePrice!
                }
            }
            return amount
        }
    }
    
    override init(){
        self.issueID = 0
        self.issueDate = DateFormatter().date(from: "")!
        self.booksOrdered = []
        super.init()
    }
    
    override func display() -> String {
        var returnData = ""
        
        returnData += "\n Issue ID : \(self.issueID)"
        returnData += "\n Issue Date : \(self.issueDate )"
        //        returnData += super.displayData()
        returnData += "\n Issued books List : "
        if !self.booksOrdered.isEmpty{
            for (_, book) in self.booksOrdered{
                returnData += "\n \tProduct : \(book.display())"
                
            }
        }else{
            returnData += "\n No products in the order"
        }
   
        returnData += "\n Total  Amount : \(self.issueAmount  )"
        
        return returnData
    }
    
    func addBook() {
        dataHelper.displayBooks()
        print("Please enter Book ID to choose any book from the list : ")
        let selectedBookID : Int = (Int)(readLine()!)!
        
        if let selectedBook = dataHelper.searchBook(bookID: selectedBookID){
            self.IssueID = selectedBookID
            self.issueDate = Date()
            
            self.booksOrdered += [(bookID: selectedBookID, book: selectedBook)]
            
        }else{
            print("Sorry...The book you entered is unavailable")
        }
    }
}


