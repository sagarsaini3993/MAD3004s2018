//
//  Book.swift
//  Sagar_736242_MAD3004_FT
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Book : Author{
    
    
    private var bookID: String
    private var title : String
    private var category : BookCategory
    private var refundablePrice : Double
  
    var BookID : String? {
        get{ return self.bookID }
        
    }
    var Title : String? {
        get { return self.title }
        
    }
    var Category : BookCategory? {
        get{ return self.category }
        
    }
    var RefundablePrice : Double? {
        get{ return self.refundablePrice}
        
    }
   
    override init(){
        self.bookID = ""
        self.title = ""
        self.category = BookCategory.None
        self.refundablePrice = 0.0
        super.init()
    }
    
    init(bookID: String, title: String, category: BookCategory, refundablePrice: Double, authorID: String, name: String, country: String){
        self.bookID = bookID
        self.title = title
        self.category = category
        self.refundablePrice = refundablePrice
       super.init(authorID: authorID, name: name, country: country)
    }
    
    override func display() -> String {
        var returnData = ""
        returnData += "\t \(self.bookID ?? "") ------ \(self.title ?? "") ------ \(self.category ?? BookCategory.None)  ------ \(self.RefundablePrice ?? 0.0)"
        return returnData
    }
    
}

