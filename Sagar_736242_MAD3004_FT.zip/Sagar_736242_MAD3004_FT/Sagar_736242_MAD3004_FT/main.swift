//
//  main.swift
//  Sagar_736242_MAD3004_FT
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var dbHelper = DataHelper()
var bookIssu = BookIssue()
var choice = 1

var username = readLine()
var pass = readLine()

if username == "sagar" && pass == "saini" {
    
} else {
    print("Invalid credentials")
}

while choice != 4{
    print("\n----What would you like to do today !----")
    print("\t 1 : Show Books ")
    print("\t 2 : Issue Book ")
    print("\t 3 : Show Issued Books ")
    print("\t 4 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        dbHelper.displayBooks()
        print("Code to display list of books")
    case 2:
        bookIssu.addBook()
        print("Code to issue a book")
    case 3:
        bookIssu.display()
        print("Code to display issued book list")
    case 4:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
}

