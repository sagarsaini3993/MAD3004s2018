//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var greet = """
hello Friends,
How are you doing!
cludy weather...
boring class
Funny Friends
"""

print(greet)

let mood = "\u{1F496}"

print(mood)

if mood.isEmpty
{
    print("no mood")
}
else{
  greet += mood
}

print(greet)

var team = String()
team = "Croatia"
print(team)

for i in team{
    print(i)
}

var initial : Character = "J"
team.append(initial)
print(team)

team.append(" Go Go GO")
print(team)

print("length of team :  ",team.count)

print("start index of our team: \(team[team.startIndex])")
//print("end index of our team : \(team[team.endIndex])")
print("last character of team : \(team[team.index(before: team.endIndex)])")
print("some character : \(team[team.index(after:team.startIndex)])")
print("third character : \(team[team.index(team.startIndex,offsetBy:3)])")
 print("fifth last character :\(team[team.index(team.endIndex,offsetBy:-5)])")
var idx = (team[team.index(team.endIndex,offsetBy:-5)])
print("\(idx)")
//print(team[idx])

for index in greet.indices{
    print("\(greet[index])", separator: "_", terminator: "_")
}

for (index, value) in team.enumerated(){
    print("Index : \(index) --- Value : \(value)")
}

print(team)
team.insert("!", at:team.endIndex)
team.insert(contentsOf: "win it..", at:team.endIndex)
print(team)

var idxG = team.index(of: "G") ?? team.endIndex
team.removeSubrange(team.startIndex..<idxG)
print(team)

 idxG = team.index(of: "G") ?? team.endIndex
team.removeSubrange(team.startIndex...idxG)
print(team)

var idxI = team.index(of:"t") ?? team.endIndex
var idxW = team.index(of:"W") ?? team.endIndex
var win = team[idxW..<idxI]
print("\(win)")
var idxLast = win.index(win.endIndex,offsetBy: -2)
win = win[win.startIndex...idxLast]
print("\(win)")

print(team.uppercased())
print(team.lowercased())

print("\(team.removeAll())")
var grade : String?
grade="A"
let finalGrade = grade ?? "F"
print("\(finalGrade)")






























